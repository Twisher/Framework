//
//  FastBotCreativePlugin.h
//  FastBotCreativePlugin
//
//  Created by wishes on 2020/12/23.
//

#import <Foundation/Foundation.h>

//! Project version number for FastBotCreativePlugin.
FOUNDATION_EXPORT double FastBotCreativePluginVersionNumber;

//! Project version string for FastBotCreativePlugin.
FOUNDATION_EXPORT const unsigned char FastBotCreativePluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FastBotCreativePlugin/PublicHeader.h>


